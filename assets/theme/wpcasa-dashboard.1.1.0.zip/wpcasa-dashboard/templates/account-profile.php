<div class="profile-form-wrapper">
	<?php echo $form; ?>
</div><!-- .login-form-wrapper -->
