jQuery(window).load(function() {
	
	jQuery('#dsidx-resp-location, input.dsidx-text, .dsidx-contact-form-comments, .dsidx-resp-search-form input[type="text"]').addClass('form-control');
	jQuery('input.dsidx-resp-submit, .dsidx-resp-area-submit input').addClass('btn btn-primary btn-block');	
    jQuery('input.dsidx-contact-form-submit').addClass('btn btn-primary');

});