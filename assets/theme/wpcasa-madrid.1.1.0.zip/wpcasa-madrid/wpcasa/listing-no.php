<div class="bs-callout bs-callout-primary">
	<p><?php _e( 'Sorry, but no listing matches your criteria.', 'wpcasa' ); ?></p>	
</div>