<?php
/**
 * Pricing Table
 */
if ( ! defined( 'ABSPATH' ) )
	exit;
?>

<div class="wpsight-alert alert alert-error">
	<?php _e( 'A pricing table with this ID does not exist.', 'wpcasa-pricing-tables' ); ?>
</div>